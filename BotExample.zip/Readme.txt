--------------------------------------------------------------------------

Run console app from command prompt passing port parameter.

  BotExample 5999


--------------------------------------------------------------------------

The bot by default is configured to return valid random move.

Add your logic opening BotExample.sln and make changes to BotAIClass.cs


TIP:  BotAIClass.GetMove() is the method that informs the server of your move

--------------------------------------------------------------------------
